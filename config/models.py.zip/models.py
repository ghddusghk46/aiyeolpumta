from django.db import models

class StudyRecord(models.Model):
    study_time = models.IntegerField()  
    goal_percent = models.PositiveIntegerField()  
    feedback = models.TextField()  
    date = models.DateField(auto_now_add=True)  

    def __str__(self):
        return f"{self.date} - {self.study_time}초"
